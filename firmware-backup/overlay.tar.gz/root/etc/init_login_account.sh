#!/bin/sh
if [ ! -f "/www/data/init_account_flag" ]
then
        echo "no flag file" > /tmp/test_jyl
		echo > /www/data/pswd.htdigest
		echo > /etc/account_permission
else
	account=`cat /www/data/pswd.htdigest`
	if [ ! -z "${account}" ]
	then
		echo "read accouunt" > /tmp/test_jyl
		echo "$account" >> /tmp/test_jyl
		echo "account exist, do nothing" >> /tmp/test_jyl
		echo "account exist, do nothing" > /www/data/init_account_flag
        exit 1
	else
		echo "flag exist, but account is null, need re-create" > /tmp/test_jyl
		rm /www/data/init_account_flag
	fi
fi
KEY=`serial_atcmd at*mrd_imei? | grep -oE '[0-9]+' | cut -b 8-15`
echo $KEY > /tmp/test_jyl
translate()
{
	tmp=$1
	case "$tmp" in
	0)
		return 7
	;;
	1)
		return 0
	;;
	2)
		return 5
	;;
	3)
		return 9
	;;
	4)
		return 8
	;;
	5)
		return 6
	;;
	6)
		return 1
	;;
	7)
		return 2
	;;
	8)
		return 3
	;;
	9)
		return 4
	;;
	esac
}
translateCap()                                                                  
{                                                                            
        tmp=$1                                                               
        index=0                                                              
        for i in A B C D E F G H I J K L M N O P Q R S T U V W X Y Z         
        do                                                                                                                                                                               
        if [ $index -eq $tmp ];then                                          
	   echo $i                                                        
        fi 
	index=`expr $index + 1`                                                                  
        done                                                                
}
cap=26 
translateLow()                                                                  
{                                                                            
        tmp=$1                                                               
        index=0                                                              
        for i in a b c d e f g h i j k l m n o p q r s t u v w x y z         
        do                                                                                                                                                                              
        if [ $index -eq $tmp ];then                                          
	   echo $i                                                        
        fi
	index=`expr $index + 1`                                                                   
        done                                                                
}
low=26
translateSep()                                                                  
{                                                                            
        tmp=$1                                                               
        index=0                                                              
        for i in "!" "@" "#" "$" "%" "&"          
        do                                                                                                                                                                              
        if [ $index -eq $tmp ];then                                          
      	   echo $i                                                        
        fi
	index=`expr $index + 1`                                                                   
        done                                                                
}
sep=6  
a0=${KEY:0:1}
a1=${KEY:1:1}
a2=${KEY:2:1}
a3=${KEY:3:1}
a4=${KEY:4:1}
a5=${KEY:5:1}
a6=${KEY:6:1}
a7=${KEY:7:1}
a8=${KEY:8:1}
a9=${KEY:9:1}
a10=${KEY:10:1}
a11=${KEY:11:1}
a12=${KEY:12:1}
a13=${KEY:13:1}
a14=${KEY:14:1}
translate $a0
a0=$?

translate $a1
a1=$?

translate $a2
a2=$?

translate $a3
a3=$?

translate $a4
a4=$?

translate $a5
a5=$?

translate $a6
a6=$?

translate $a7
a7=$?

translate $a8
a8=$?

translate $a9
a9=$?

translate $a10
a10=$?

translate $a11
a11=$?

translate $a12
a12=$?

translate $a13
a13=$?

translate $a14
a14=$?

sum0=`expr $a0 + $a1 + $a2 + $a3 + $a4 + $a5 + $a6 + $a7`
b0=$(( $sum0 % $cap ))
c0=$(translateCap $b0)
#echo after translate
echo "sum0 =="$a0 + $a1 + $a2 + $a3 + $a4 + $a5 + $a6 + $a7=$sum0"=="$b0,$c0 >> /tmp/test_jyl

sum1=`expr $a1 + $a2 + $a3 + $a4 + $a5 + $a6 + $a7 + $a8`
b1=$(( $sum1 % $low ))
c1=$(translateLow $b1)
echo "sum1 =="$a1 + $a2 + $a3 + $a4 + $a5 + $a6 + $a7 + $a8=$sum1"=="$b1,$c1 >> /tmp/test_jyl

sum2=`expr $a2 + $a3 + $a4 + $a5 + $a6 + $a7 + $a8 + $a9`
b2=$(( $sum2 % $sep ))
c2=$(translateSep $b2)
echo "sum2 =="$a2 + $a3 + $a4 + $a5 + $a6 + $a7 + $a8 + $a9=$sum2"=="$b2,$c2 >> /tmp/test_jyl

sum3=`expr  $a3 + $a4 + $a5 + $a6 + $a7 + $a8 + $a9 + $a10`
b3=$(( $sum3 % 10 ))
c3=$b3
echo "sum3 =="$a3 + $a4 + $a5 + $a6 + $a7 + $a8 + $a9 + $a10=$sum3"=="$b3,$c3 >> /tmp/test_jyl

sum4=`expr $a4 + $a5 + $a6 + $a7 + $a8 + $a9 + $a10 + $a11`
b4=$(( $sum4 % $cap ))
c4=$(translateCap $b4)
echo "sum4 =="$a4 + $a5 + $a6 + $a7 + $a8 + $a9 + $a10 + $a11=$sum4"=="$b4,$c4 >> /tmp/test_jyl

sum5=`expr $a5 + $a6 + $a7 + $a8 + $a9 + $a10 + $a11 + $a12`
b5=$(( $sum5 % $low ))
c5=$(translateLow $b5)
echo "sum5 =="$a5 + $a6 + $a7 + $a8 + $a9 + $a10 + $a11 + $a12=$sum5"=="$b5,$c5 >> /tmp/test_jyl

sum6=`expr $a6 + $a7 + $a8 + $a9 + $a10 + $a11 + $a12 + $a13`
b6=$(( $sum6 % $sep ))
c6=$(translateSep $b6)
echo "sum6 =="$a6 + $a7 + $a8 + $a9 + $a10 + $a11 + $a12 + $a13=$sum6"=="$b6,$c6 >> /tmp/test_jyl

sum7=`expr  $a7 + $a8 + $a9 + $a10 + $a11 + $a12 + $a13 + $a14`
b7=$(( $sum7 % 10 ))
c7=$b7
echo "sum7 =="$a7 + $a8 + $a9 + $a10 + $a11 + $a12 + $a13 + $a14=$sum7"=="$b7,$c7 >> /tmp/test_jyl

echo "before make ssid key=====" >> /tmp/test_jyl
nkey="${b0}${b1}${b2}${b3}${b4}${b5}${b6}${b7}"
echo test KEY $nkey >> /tmp/test_jyl
nkeyChar="${c0}${c1}${c2}${c3}${c4}${c5}${c6}${c7}"
echo test Key $nkeyChar >> /tmp/test_jyl
                                                                        
#set account super admin
account="admin"
format="${account}:Highwmg:${nkeyChar}"
md5=`echo -n $format| md5sum | cut -c 0-32`
data="${account}:Highwmg:${md5}"
data_permission="${account}:${permission}"

echo "create super admin" >> /tmp/test_jyl
echo "account+++${account}+++" >> /tmp/test_jyl
echo "pasw+++${nkeyChar}+++" >> /tmp/test_jyl
echo "pasw_md5+++${md5}+++" >> /tmp/test_jyl
echo $data > /www/data/pswd.htdigest                                                                        

#set flag file
touch /www/data/init_account_flag
echo "init flag file" > /www/data/init_account_flag
